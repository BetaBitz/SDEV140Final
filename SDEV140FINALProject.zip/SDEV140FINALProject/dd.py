class Book:
    def __init__(self, title, author_name, pub_name):
        self.title=title
        self.author_name=author_name
        self.pub_name=pub_name

    def set(self, instance, value):
        if instance == 'title':
            self.title = value
        elif instance == 'author_name':
            self.author_name = value
        elif instance == 'pub_name':
            self.pub_name = value

    def get(self):
        return self.title, self.author_name, self.pub_name

    def __str__(self):
        return f"{self.title} {self.author_name} {self.pub_name}"


b = Book('great', 'bob', 'jill')

print(b.get())
print(b.__str__())



