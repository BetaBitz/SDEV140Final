import os
import tkinter
from tkinter import *
from tkinter import messagebox
import sqlite3
import tkintermapview
from PIL import Image, ImageTk
import tkinter.ttk as ttk

# ------------------------------Create a database--------------------------------------------------------
'''conn = sqlite3.connect('techequipment3.db')
c = conn.cursor()
c.execute("""CREATE TABLE techequipment (
    first_name text,
    last_name text,
    street_address text,
    city text,
    state text,
    zipcode integer,
    cost_center text,
    equipment_consscan text,
    equipment_drone text,
    equipment_pushpull text,
    equipment_gpscollection text,
    tech_sup_storage text
    )""")

# Commit DB changes
conn.commit()
# Close DB connection
conn.close()'''


# Blood Hound database of specialty equipment and where it is located in the country
# Created by Nick Fulton 2022

# String variables
addEntryString = 'Add Entry To Database'
findString = 'Find Techician, Supervisor or Storage unit'
withString = 'With Specialty Equipment'
progressString = 'Progress bar'
queryString = 'Get Equipment!'
emptyString = ''
mapAddressList = []
marker_list = []
txtEmpty = TRUE
# ---------Color Pallette-----------------------------
peachC = '#F0896C'
pinkC = '#FA7AB7'
purpleC = '#AE5BE0'
blueC = '#51C0F0'

# what image to pick
picked = None
# ------------------------------------------- tkinter setup ---------------------------------------------------------------
# Create tkinter root window
root = Tk()
# set root window title
root.configure(bg="lightgrey")
root.title('Blood Hound DB')
# set root window icon
root.iconbitmap("./allcompany.ico")
# set width/height variable for root window
width = root.winfo_screenwidth()
height = root.winfo_screenheight()
# set root window at percent of full screen
root.geometry("%dx%d+0+0" % (width * .685, height * .595))

# Create left menu frame
leftFrame = Frame(root, bg='lightgrey', highlightbackground="black", highlightthickness=1, width=401, height=height * .534)
leftFrame.place(x=0, y=63)

# Create top frame
topFrame = Frame(root, bg='lightgrey', highlightbackground="black", highlightthickness=1, width=1760, height=25)
topFrame.place(x=0, y=0)

# Create frame under top frame
topSecondFrame = Frame(root, bg='lightgrey', highlightbackground="black", highlightthickness=1, width=1760, height=40)
topSecondFrame.place(x=0, y=24)

# Create bottom status frame
statusFrame = Frame(root, bg='lightgrey', highlightbackground="black", highlightthickness=1, width=1760, height=30)
statusFrame.place(x=0, y=828)

# Create frame for map
mapFrame = Frame(root, background="lightgrey", highlightbackground="black", highlightthickness=1, width=width * .53,
                 height=height * .532)
mapFrame.place(x=400, y=63)
map_widget = tkintermapview.TkinterMapView(mapFrame, width=width * .53, height=height * .53)
map_widget.place(relx=0.5, rely=0.5, anchor=tkinter.CENTER)
map_widget.set_address("emporia, kansas")
map_widget.set_zoom(5)

# Create frame for map
mapFrame = Frame(root, background="lightgrey", highlightbackground="black", highlightthickness=1, width=width * .53,
                 height=height * .532)
mapFrame.place(x=400, y=63)
map_widget = tkintermapview.TkinterMapView(mapFrame, width=width * .53, height=height * .53)
map_widget.place(relx=0.5, rely=0.5, anchor=tkinter.CENTER)
map_widget.set_address("emporia, kansas")
map_widget.set_zoom(5)


# clear map frame
def clear_map():
    global mapFrame
    global map_widget
    mapFrame = Frame(root, background="lightgrey", highlightbackground="black", highlightthickness=1, width=width * .53,
                 height=height * .532)
    mapFrame.place(x=400, y=63)
    map_widget = tkintermapview.TkinterMapView(mapFrame, width=width * .53, height=height * .53)
    map_widget.place(relx=0.5, rely=0.5, anchor=tkinter.CENTER)
    map_widget.set_address("emporia, kansas")
    map_widget.set_zoom(5)


progressBar = ttk.Progressbar(statusFrame, orient="horizontal", mode="determinate", maximum=100, value=0)
progressBar.place(x=90, y=3)
progressBarLabel = Label(statusFrame, text="Progress Bar", background='lightgrey')
progressBarLabel.place(x=10, y=3)


def about_window():
    aboutBtn["state"] = "disabled"

    def exit_btn(window):
        aboutBtn["state"] = "normal"
        window.destroy()

    # create window for program info
    aboutWindow = Toplevel(bg="lightgrey")
    # set window title
    aboutWindow.title('About')
    # set window icon
    aboutWindow.iconbitmap("./allcompany.ico")
    # set window size
    aboutWindow.geometry('160x100')
    aboutLabel = Label(aboutWindow, text="Made By: Nicholas Fulton \n SDEV140 \n ver .10.1" , background='lightgrey')
    aboutLabel.place(x=10, y=20)
    # Exit About button
    exAboutBtn = Button(aboutWindow, text="Exit", background='lightgrey', command=lambda: exit_btn(aboutWindow))
    exAboutBtn.place(x=70, y=80)


# quit program
def quit_app():
    root.destroy()


# ------------------------------------------------------------Database entry window items------------------------------------
# Add entry on click function -- ALL ADD DB ENTRY LOGIC UNDER HERE
def add_entry_onclick():
    # disable button while window is open
    addEntryBtn["state"] = "disabled"
    # create window to add database entry
    addEntryWindow = Toplevel(bg="lightgrey")
    # set window title
    addEntryWindow.title('Add Entry')
    # set window icon
    addEntryWindow.iconbitmap("./allcompany.ico")
    # set window size
    addEntryWindow.geometry("400x500")

    # -------------------------------------------------Drop Down variables----------------------------------------------------------------------
    ccOptions = ["8101", "8102", "8103", "8109", "9013"]
    ccClicked = StringVar()
    ccClicked.set(" ")
    conscanOptions = ["No", "Yes"]
    conscanClicked = StringVar()
    conscanClicked.set("No")
    droneOptions = ["No", "Yes"]
    droneClicked = StringVar()
    droneClicked.set("No")
    pushpullOptions = ["No", "Yes"]
    pushpullClicked = StringVar()
    pushpullClicked.set("No")
    gpscollectOptions = ["No", "Yes"]
    gpscollectClicked = StringVar()
    gpscollectClicked.set("No")
    tech_sup_storage_Options = ["Technician", "Supervisor", "Storage Unit"]
    tech_sup_storage_Clicked = StringVar()
    tech_sup_storage_Clicked.set("Technician")

    # check if text boxes are empty
    def text_empty():
        global txtEmpty
        if not f_name.get():
            txtEmpty = TRUE
        else:
            txtEmpty = FALSE
        if not l_name.get():
            txtEmpty = TRUE
        else:
            txtEmpty = FALSE
        if not s_address.get():
            txtEmpty = TRUE
        else:
            txtEmpty = FALSE
        if not city.get():
            txtEmpty = TRUE
        else:
            txtEmpty = FALSE
        if not state.get():
            txtEmpty = TRUE
        else:
            txtEmpty = FALSE
        if not zipcode.get():
            txtEmpty = TRUE
        else:
            txtEmpty = FALSE

    # Create DB text boxes
    f_name = Entry(addEntryWindow, width=30, font=('Arial', 10))
    f_name.grid(row=0, column=1, padx=0, pady=(5, 5))
    l_name = Entry(addEntryWindow, width=30, font=('Arial', 10))
    l_name.grid(row=1, column=1, padx=0, pady=(5, 5))
    s_address = Entry(addEntryWindow, width=30, font=('Arial', 10))
    s_address.grid(row=2, column=1, padx=0, pady=(5, 5))
    city = Entry(addEntryWindow, width=30, font=('Arial', 10))
    city.grid(row=3, column=1, padx=20, pady=(5, 5))
    state = Entry(addEntryWindow, width=30, font=('Arial', 10))
    state.grid(row=4, column=1, padx=20, pady=(5, 5))
    zipcode = Entry(addEntryWindow, width=30, font=('Arial', 10))
    zipcode.grid(row=5, column=1, padx=20, pady=(5, 5))
    cc = OptionMenu(addEntryWindow, ccClicked, *ccOptions)
    cc.config(width=29, bg='lightgrey', font=('Arial', 8))
    cc.grid(row=6, column=1, padx=20, pady=(5, 5))
    conscan_option = OptionMenu(addEntryWindow, conscanClicked, *conscanOptions)
    conscan_option.config(width=29, bg='lightgrey', font=('Arial', 8))
    conscan_option.grid(row=7, column=1, padx=20, pady=(5, 5))
    drone_option = OptionMenu(addEntryWindow, droneClicked, *droneOptions)
    drone_option.config(width=29, bg='lightgrey', font=('Arial', 8))
    drone_option.grid(row=8, column=1, padx=20, pady=(5, 5))
    pushpull_option = OptionMenu(addEntryWindow, pushpullClicked, *pushpullOptions)
    pushpull_option.config(width=29, bg='lightgrey', font=('Arial', 8))
    pushpull_option.grid(row=9, column=1, padx=20, pady=(5, 5))
    gpscollect_option = OptionMenu(addEntryWindow, gpscollectClicked, *gpscollectOptions)
    gpscollect_option.config(width=29, bg='lightgrey', font=('Arial', 8))
    gpscollect_option.grid(row=10, column=1, padx=20, pady=(5, 5))
    tech_sup_storage_option = OptionMenu(addEntryWindow, tech_sup_storage_Clicked, *tech_sup_storage_Options)
    tech_sup_storage_option.config(width=29, bg='lightgrey', font=('Arial', 8))
    tech_sup_storage_option.grid(row=11, column=1, padx=20, pady=(5, 5))

    # Create labels
    f_name_label = Label(addEntryWindow, text="First Name", bg='lightgrey')
    f_name_label.grid(row=0, column=0, pady=(10, 0))
    l_name_label = Label(addEntryWindow, text="Last Name", bg='lightgrey')
    l_name_label.grid(row=1, column=0)
    s_address_label = Label(addEntryWindow, text="Address", bg='lightgrey')
    s_address_label.grid(row=2, column=0)
    city_label = Label(addEntryWindow, text="City", bg='lightgrey')
    city_label.grid(row=3, column=0)
    state_label = Label(addEntryWindow, text="State", bg='lightgrey')
    state_label.grid(row=4, column=0)
    zipcode_label = Label(addEntryWindow, text="Zipcode", bg='lightgrey')
    zipcode_label.grid(row=5, column=0)
    cc_label = Label(addEntryWindow, text="Cost Center", bg='lightgrey')
    cc_label.grid(row=6, column=0)
    conscan_label = Label(addEntryWindow, text="Concrete Scanner?", bg='lightgrey')
    conscan_label.grid(row=7, column=0)
    drone_label = Label(addEntryWindow, text="Drone?", bg='lightgrey')
    drone_label.grid(row=8, column=0)
    pushpull_label = Label(addEntryWindow, text="Push Pull?", bg='lightgrey')
    pushpull_label.grid(row=9, column=0)
    gpscollect_label = Label(addEntryWindow, text="GPS Collector?", bg='lightgrey')
    gpscollect_label.grid(row=10, column=0)
    tech_sup_storage_label = Label(addEntryWindow, text="Select ID", bg='lightgrey')
    tech_sup_storage_label.grid(row=11, column=0)

    def submit():
        # Connect to database
        conn = sqlite3.connect('techequipment3.db')
        # Create cursor
        c = conn.cursor()
        # Insert into table
        c.execute(
            "INSERT INTO techequipment VALUES (:f_name, :l_name, :s_address, :city, :state, :zipcode, :cc, :conscan, :drone, :pushpull, :gpscollect, :tech_sup_storage)",
            {
                'f_name': f_name.get(),
                'l_name': l_name.get(),
                's_address': s_address.get(),
                'city': city.get(),
                'state': state.get(),
                'zipcode': zipcode.get(),
                'cc': ccClicked.get(),
                'conscan': conscanClicked.get(),
                'drone': droneClicked.get(),
                'pushpull': pushpullClicked.get(),
                'gpscollect': gpscollectClicked.get(),
                'tech_sup_storage': tech_sup_storage_Clicked.get()
            })
        # Commit changes
        if not txtEmpty:
            print(txtEmpty)
            conn.commit()
            # Close connection
            conn.close()
            # enable add entry button again
            addEntryBtn["state"] = "normal"
        elif txtEmpty:
            print(txtEmpty)
            messagebox.showwarning(title="Data missing", message="You have incomplete fields")
            addEntryBtn["state"] = "normal"

    def exit_btn(window):
        addEntryBtn["state"] = "normal"
        window.destroy()

    submitEntryBtn = Button(addEntryWindow, bg='lightgrey', text="Submit", command=submit)
    submitEntryBtn.grid(row=12, column=0)
    # Exit About button
    exAboutBtn = Button(addEntryWindow, text="Exit", background='lightgrey', command=lambda: exit_btn(addEntryWindow))
    exAboutBtn.grid(row=12, column=1)


# Button hover status bar tips functions
# on button hover tip
def on_button_hover(my_tip):
    statusLabel.config(text=my_tip)


# on button stop hovering
def on_button_leave(my_tip):
    statusLabel.config(text=my_tip)


# -----------------------------------------------image variables------------------------------------------------------------------
current_path = os.path.join(os.path.dirname(os.path.abspath(__file__)))
concreteScannerImage = ImageTk.PhotoImage(Image.open(os.path.join(current_path, "concrete_scanner.png")).resize((30, 30)))
droneImage = ImageTk.PhotoImage(Image.open(os.path.join(current_path, "drone.png")).resize((30, 30)))
pushPullImage = ImageTk.PhotoImage(Image.open(os.path.join(current_path, "hose_reel.png")).resize((30, 30)))
gpsCollectorImage = ImageTk.PhotoImage(Image.open(os.path.join(current_path, "satellite.png")).resize((25, 25)))
# ----------------------------------------------------DB Functions-------------------------------------------------------------------------


# Query DB function
def query_db():
    clear_map()
    mapAddresses = []
    mapAddressList.clear()
    # Connect to database
    conn = sqlite3.connect('techequipment3.db')
    # Create cursor
    c = conn.cursor()
    # Query database
    c.execute(pick_equipment(equipClicked.get()))
    records = c.fetchall()
    # Commit changes
    conn.commit()
    # Close connection
    conn.close()
    # Loop through records

    for record in records:
        print(record)
        mapAddresses.clear()
        # loop through columns in each record
        for col in record:
            # make a list for each row
            mapAddresses.append(col)

    # ---------------------------------------------Concanate Address only into a list-----------------------------------------
        mapAddressList.append(mapAddresses[2] + ", " + mapAddresses[3] + ", " + mapAddresses[4] + ", " + str(mapAddresses[5]))
    # -----------------------------------------------Convert address to LAT LONG-------------------------------------------
    for index, mapAddress in enumerate(mapAddressList):
        global progressBar
        step = 100 / len(mapAddressList)
        progressBar['value'] += step
        print(progressBar['value'])
        leftFrame.update()
        print(mapAddress)
        print(index)
        latLong = tkintermapview.convert_address_to_coordinates(mapAddress)
        # check if address converts properly to a lat,long
        print(latLong)
        if latLong:
            marker_list.append(map_widget.set_marker(latLong[0], latLong[1], text=equipClicked.get(), icon=picked))
    progressBar['value'] = 0


# Status bar label
statusLabel = Label(statusFrame, text=emptyString.ljust(110, ' '), bd=1, relief=SUNKEN, bg='lightgrey')
statusLabel.place(x=1400, y=5)
# Button icons
addEntryBtnPic = PhotoImage(file='med.png')

# -------------------------------------------------------Buttons----------------------------------------------------------------------

# About button
aboutBtn = Button(topFrame, text="About", bg='lightgrey', borderwidth=0, command=about_window)
aboutBtn.place(x=2, y=1)
# Quit button
quitBtn = Button(topFrame, text='Quit', bg='lightgrey', borderwidth=0, command=quit_app)
quitBtn.place(x=45, y=1)
# Add entry button
addEntryBtn = Button(topSecondFrame, bg='lightgrey', image=addEntryBtnPic, borderwidth=0, command=add_entry_onclick)
addEntryBtn.place(x=2, y=6)
# Add entry button bind
addEntryBtn.bind("<Enter>", lambda eff: on_button_hover(my_tip=addEntryString.ljust(91, ' ')))
addEntryBtn.bind("<Leave>", lambda eff: on_button_leave(my_tip=emptyString.ljust(110, ' ')))


# ------------------------------------------------Left Frame Inputs and Buttons and Variables-----------------------------------------------------------
techSupStorageOptions = ["Technician", "Supervisor", "Storage Unit"]
techSupStorageClicked = StringVar()
techSupStorageClicked.set("Technician")

equipOptions = ["Concrete Scanner", "Drone", "Push Pull", "GPS Collector"]
equipClicked = StringVar()

# ---------------------------------------------------FIND---------------------------------------------
findLabel1 = Label(leftFrame, text="Find", bg='lightgrey', font=('Arial', 12))
findLabel1.place(x=10, y=20)
findLabel1.bind("<Enter>", lambda eff: on_button_hover(my_tip=findString.ljust(79, ' ')))
findLabel1.bind("<Leave>", lambda eff: on_button_leave(my_tip=emptyString.ljust(110, ' ')))
# ----------------------------------------------FIND WHAT?---------------------------------------------
techSupStorageOptionMenu = OptionMenu(leftFrame, techSupStorageClicked, *techSupStorageOptions)
techSupStorageOptionMenu.config(width=29, bg='lightgrey', font=('Arial', 12))
techSupStorageOptionMenu.place(x=60, y=18)
# -------------------------------------------------WITH--------------------------------------------------------
withLabel1 = Label(leftFrame, text="With", bg='lightgrey', font=('Arial', 12))
withLabel1.place(x=10, y=80)
withLabel1.bind("<Enter>", lambda eff: on_button_hover(my_tip=withString.ljust(89, ' ')))
withLabel1.bind("<Leave>", lambda eff: on_button_leave(my_tip=emptyString.ljust(110, ' ')))
# -----------------------------------------------WITH WHAT?-----------------------------------------------
equipOptionMenu = OptionMenu(leftFrame, equipClicked, *equipOptions)
equipOptionMenu.config(width=29, bg='lightgrey', font=('Arial', 12))
equipOptionMenu.place(x=60, y=78)

# -----------------------------------------------Query DB Button-------------------------------------------------
queryDBButton = Button(leftFrame, bg='lightgrey', text="Find", font=('Arial', 12),  command=query_db)
queryDBButton.place(x=10, y=150)
queryDBButton.bind("<Enter>", lambda eff: on_button_hover(my_tip=queryString.ljust(97, ' ')))
queryDBButton.bind("<Leave>", lambda eff: on_button_leave(my_tip=emptyString.ljust(110, ' ')))
# ---------------------------------------------Legend---------------------------------------------------------
# Legend text
legendLabel = Label(leftFrame, text="Legend", bg='lightgrey', font=('Arial', 12))
legendLabel.place(x=170, y=200)
# Concrete Scanner text
conScanLabel = Label(leftFrame, text="Concrete Scanner", bg='lightgrey', font=('Arial', 12))
conScanLabel.place(x=10, y=260)
# Concrete Scanner icon
conScanPicLabel = Label(leftFrame, image=concreteScannerImage, bg='lightgrey')
conScanPicLabel.place(x=200, y=250)
# Drone text
droneLabel = Label(leftFrame, text="Drone", bg='lightgrey', font=('Arial', 12))
droneLabel.place(x=10, y=310)
# Drone Icon
dronePicLabel = Label(leftFrame, image=droneImage, bg='lightgrey')
dronePicLabel.place(x=200, y=300)
# Push Pull Camera text
pushpullLabel = Label(leftFrame, text="Push Pull Camera", bg='lightgrey', font=('Arial', 12))
pushpullLabel.place(x=10, y=360)
# Push Pull Camera icon
pushPullPicLabel = Label(leftFrame, image=pushPullImage, bg='lightgrey')
pushPullPicLabel.place(x=200, y=350)
# GPS Collector text
gpsCollectorLabel = Label(leftFrame, text="GPS Collector", bg='lightgrey', font=('Arial', 12))
gpsCollectorLabel.place(x=10, y=410)
# GPS Collector icon
gpsCollectorPicLabel = Label(leftFrame, image=gpsCollectorImage, bg='lightgrey')
gpsCollectorPicLabel.place(x=200, y=400)


# -----------------------------function to decide which equipment we are searching for in the database------------------
def pick_equipment(equip):
    global picked
    if equip == "Concrete Scanner":
        picked = concreteScannerImage
        return "SELECT * FROM techequipment WHERE equipment_consscan = 'Yes'"
    if equip == "Drone":
        picked = droneImage
        return "SELECT * FROM techequipment WHERE equipment_drone = 'Yes'"
    if equip == "Push Pull":
        picked = pushPullImage
        return "SELECT * FROM techequipment WHERE equipment_pushpull = 'Yes'"
    if equip == "GPS Collector":
        picked = gpsCollectorImage
        return "SELECT * FROM techequipment WHERE equipment_gpscollection = 'Yes'"


root.mainloop()
